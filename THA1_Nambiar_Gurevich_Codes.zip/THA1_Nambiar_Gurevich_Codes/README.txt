main.m--excecutable which contains all test cases
angle_axis_func.m--Calculating angle and axis from rotation matrix
quaternion_func.m--Determine quaternion and validity from a rotation matrix
euler_angle_func.m--Calculating euler angles ZYZ and ZYX
AxisAngle2RotMat.m--Calculating Rotation Matrix from Axis Angle format
Quat2RotMat.m--Calculating rotation matrix from quaternion
Question3.m--Plotting screw operation
qsh2screw.m--Calculating screw matrix from q s h form
configuration_calculator.m--Calculating 3 intermediate configurations and final configuration
TMatrix2ScrewAngle.m--Calculating screw matrix 4x4 and theta from transform
screw2qsh.m--Calculating q s h of screw from screw matrix
Bonus_Math_10.m--Calculates closest rotation matrix to given matrix
Matrix_R.m--Calcualtes a rotation matrix given euler angles
Matrix_Difference_Norm.m--Calculates the matrix difference norm
Bonus_Programming_4.m--Returns boolean and similar SO(3) matrix to input
