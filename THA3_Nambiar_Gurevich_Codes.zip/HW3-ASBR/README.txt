Hand_Eye_Axis_Angle.m--Uses Axis-angle method to solve AX=XB
Hand_Eye_Quaternion.m--Uses Quaternion method to solve AX=XB
PA1P3.m--D A C d a c (distortion calibration dataset)
PA1P4.m--Generates tip vector relative to ee and post vector
PA1P5.m--Generates tip vector relative to ee and post vector
PA2.m--Tests Hand-Eye Algorithms
pivot_calibration_em.m--Generates tip vector relative to ee and post vector
pivot_calibration_opt.m--Generates tip vector relative to ee and post vector
set_registration.m--Generates Optimal Transformation Matrix T to go from set A to B


